#include <stdio.h>
#include <stdbool.h>
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_task_wdt.h"
#include "hal/gpio_types.h"

// Mapeamento de Pinos para ESP32-S3
#define BUTTON_PIN GPIO_NUM_4
#define LED_PIN GPIO_NUM_2

// Tempos em microssegundos (us)
#define DEBOUNCE_TIME_US   25000ULL     // 25 ms
#define LONG_PRESS_TIME_US 2000000ULL    // 2 segundos
#define LED_TIMEOUT_US     30000000ULL   // 30 segundos

void app_main(void) {
    // Configuração do GPIO do LED (Saída)
    gpio_config_t led_conf = {
        .pin_bit_mask = (1ULL << LED_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&led_conf);
    gpio_set_level(LED_PIN, 0);

    // Configuração do GPIO do Botão
    gpio_config_t btn_conf = {
        .pin_bit_mask = (1ULL << BUTTON_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&btn_conf);

    // Variáveis de Estado do Sistema
    bool led_state = false;
    bool last_raw_button = false;
    bool debounced_button = false;
    bool long_press_handled = false;

    // Registros de Marcação de Tempo (em microssegundos)
    int64_t last_debounce_time = 0;
    int64_t button_press_start_time = 0;
    int64_t led_start_time = 0;

    // Laço Principal (Polling Não Bloqueante)
    while (1) {
        // Alimenta o Watchdog Timer no ESP32-S3 para evitar reinicialização
        #if defined(CONFIG_ESP_TASK_WDT_ENABLED)
        esp_task_wdt_reset();
        #endif

        int64_t current_time = esp_timer_get_time();
        bool current_raw_button = (gpio_get_level(BUTTON_PIN) == 1);

        // --- 1. TRATAMENTO DE DEBOUNCE POR SOFTWARE ---
        if (current_raw_button != last_raw_button) {
            last_debounce_time = current_time;
            last_raw_button = current_raw_button;
        }

        if ((current_time - last_debounce_time) >= DEBOUNCE_TIME_US) {
            if (current_raw_button != debounced_button) {
                debounced_button = current_raw_button;

                // Evento: Botão pressionado (Borda de subida)
                if (debounced_button) {
                    button_press_start_time = current_time;
                    long_press_handled = false;

                    // Condições 1 e 2: Ligar ou reiniciar temporizador (30s)
                    led_state = true;
                    led_start_time = current_time;
                    gpio_set_level(LED_PIN, 1);
                    printf("Botao pressionado -> LED LIGADO / Timer (30s) iniciado ou resetado.\n");
                }
            }
        }

        // --- 2. CONDIÇÃO 3: DESLIGAMENTO MANUAL POR PRESSIONAMENTO LONGO (> 2s) ---
        if (debounced_button && led_state && !long_press_handled) {
            if ((current_time - button_press_start_time) >= LONG_PRESS_TIME_US) {
                led_state = false;
                gpio_set_level(LED_PIN, 0);
                long_press_handled = true;
                printf("Pressionamento longo (>2s) -> LED DESLIGADO manualmente.\n");
            }
        }

        // --- 3. CONDIÇÃO 1/2: DESLIGAMENTO AUTOMÁTICO APÓS 30 SEGUNDOS ---
        if (led_state) {
            if ((current_time - led_start_time) >= LED_TIMEOUT_US) {
                led_state = false;
                gpio_set_level(LED_PIN, 0);
                printf("Tempo esgotado (30s) -> LED DESLIGADO automaticamente.\n");
            }
        }
    }
}