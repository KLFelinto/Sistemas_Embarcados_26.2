#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "driver/gpio.h"

#define TXD_PIN (GPIO_NUM_17)
#define RXD_PIN (GPIO_NUM_16)
#define LED_PIN (GPIO_NUM_2)

#define UART_PORT (UART_NUM_2)
#define BUF_SIZE  (1024)

void app_main(void)
{
    // Configuração do pino do LED (GPIO 2)
    gpio_reset_pin(LED_PIN);
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);

    // Configuração da UART2
    const uart_config_t uart_config = {
        .baud_rate  = 115200,
        .data_bits  = UART_DATA_8_BITS,
        .parity     = UART_PARITY_DISABLE,
        .stop_bits  = UART_STOP_BITS_1,
        .flow_ctrl  = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ESP_ERROR_CHECK(uart_param_config(UART_PORT, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT, TXD_PIN, RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(UART_PORT, BUF_SIZE * 2, 0, 0, NULL, 0));

    // Garante inicialização da UART0 (Console do Monitor Serial)
    uart_driver_install(UART_NUM_0, BUF_SIZE, 0, 0, NULL, 0);

    uint8_t data[BUF_SIZE];
    bool ligar = true;

    printf("\n=== INICIANDO TESTE DE LOOPBACK UART2 ===\n\n");

    while (1) {
        const char *cmd_to_send = ligar ? "LIGAR" : "DESLIGAR";
        ligar = !ligar;

        // Telemetria no Console Principal (exibido via printf)
        printf("-----------------------------------\n");
        printf("[TX UART2] Mensagem enviada: %s\n", cmd_to_send);

        // Envia o comando via UART2
        uart_write_bytes(UART_PORT, cmd_to_send, strlen(cmd_to_send));

        // Leitura da UART2 com Timeout de 1000ms
        int len = uart_read_bytes(UART_PORT, data, BUF_SIZE - 1, pdMS_TO_TICKS(1000));

        if (len > 0) {
            data[len] = '\0'; // Terminação nula de segurança

            printf("[RX UART2] Mensagem lida (Loopback): %s\n", (char *)data);

            if (strcmp((char *)data, "LIGAR") == 0) {
                gpio_set_level(LED_PIN, 1);
                printf("Estado: LED LIGADO\n");
            } else if (strcmp((char *)data, "DESLIGAR") == 0) {
                gpio_set_level(LED_PIN, 0);
                printf("Estado: LED DESLIGADO\n");
            }
        } else {
            printf("Timeout: Nenhum dado lido\n");
        }

        vTaskDelay(pdMS_TO_TICKS(1500));
    }
}