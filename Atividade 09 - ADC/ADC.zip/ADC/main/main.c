#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_timer.h"

// Mapeamento dos Pinos (GPIO 4: Potenciômetro, GPIO 2: Botão, GPIO 15: LED)
#define POT_ADC_UNIT     ADC_UNIT_2
#define POT_ADC_CHANNEL  ADC_CHANNEL_0 // GPIO 4 (ADC2 Canal 0)
#define BUTTON_GPIO      GPIO_NUM_2    // GPIO 2
#define LED_GPIO         GPIO_NUM_15   // GPIO 15

// Configurações do PWM (LEDC)
#define LEDC_MODE        LEDC_LOW_SPEED_MODE
#define LEDC_CHANNEL     LEDC_CHANNEL_0
#define LEDC_TIMER       LEDC_TIMER_0
#define LEDC_DUTY_RES    LEDC_TIMER_10_BIT // 0 a 1023
#define LEDC_FREQUENCY   5000              // 5 kHz

#define DEBOUNCE_TIME_MS   200
#define SAMPLING_PERIOD_US 10000 // Período de amostragem de 10.000 us (10 ms)

typedef enum {
    MODE_LIVE = 0,
    MODE_HOLD
} system_mode_t;

// Handles e Variáveis Globais de Estado
static adc_oneshot_unit_handle_t adc_handle;
static system_mode_t current_mode = MODE_LIVE;
static int adc_raw = 0;
static uint32_t duty_cycle = 0;
static uint32_t voltage_mv = 0;

static int64_t last_button_press_time = 0;
static int64_t last_telemetry_time = 0;
static int last_button_state = 0;

// Callback executado automaticamente pelo esp_timer a cada 10 ms
static void system_timer_callback(void* arg)
{
    int64_t now_ms = esp_timer_get_time() / 1000;

    // 1. Tratamento não-bloqueante do Botão com Debounce
    int button_state = gpio_get_level(BUTTON_GPIO);
    if (button_state == 1 && last_button_state == 0) {
        if ((now_ms - last_button_press_time) > DEBOUNCE_TIME_MS) {
            current_mode = (current_mode == MODE_LIVE) ? MODE_HOLD : MODE_LIVE;
            last_button_press_time = now_ms;
            printf("Alteracao de Estado -> Modo: %s\n", (current_mode == MODE_LIVE) ? "LIVE" : "HOLD");
        }
    }
    last_button_state = button_state;

    // 2. Leitura do ADC e Atualização do PWM
    if (current_mode == MODE_LIVE) {
        if (adc_oneshot_read(adc_handle, POT_ADC_CHANNEL, &adc_raw) == ESP_OK) {
            // Escalonamento dinâmico: 12 bits (0-4095) -> 10 bits (0-1023)
            duty_cycle = (adc_raw * 1023) / 4095;
            
            ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, duty_cycle);
            ledc_update_duty(LEDC_MODE, LEDC_CHANNEL);
        }
    }

    // Cálculo da tensão calculada em mV
    voltage_mv = (adc_raw * 3300) / 4095;

    // 3. Telemetria Serial a cada 500 ms
    if ((now_ms - last_telemetry_time) >= 500) {
        printf("ADC Raw: %4d | Tensao: %4lu mV | Estado: %s\n",
               adc_raw,
               voltage_mv,
               (current_mode == MODE_LIVE) ? "LIVE" : "HOLD");
        last_telemetry_time = now_ms;
    }
}

void app_main(void)
{
    // 1. Configuração da GPIO do Botão (GPIO 2 com Pull-Down físico externo)
    gpio_config_t btn_config = {
        .pin_bit_mask = (1ULL << BUTTON_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&btn_config);

    // 2. Configuração do LEDC / PWM (GPIO 15)
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_MODE,
        .timer_num        = LEDC_TIMER,
        .duty_resolution  = LEDC_DUTY_RES,
        .freq_hz          = LEDC_FREQUENCY,
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ESP_ERROR_CHECK(ledc_timer_config(&ledc_timer));

    ledc_channel_config_t ledc_channel = {
        .speed_mode     = LEDC_MODE,
        .channel        = LEDC_CHANNEL,
        .timer_sel      = LEDC_TIMER,
        .intr_type      = LEDC_INTR_DISABLE,
        .gpio_num       = LED_GPIO,
        .duty           = 0,
        .hpoint         = 0
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ledc_channel));

    // 3. Configuração do Periférico ADC (GPIO 4 - Canal 0)
    adc_oneshot_unit_init_cfg_t init_config = {
        .unit_id = POT_ADC_UNIT,
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config, &adc_handle));

    adc_oneshot_chan_cfg_t adc_config = {
        .bitwidth = ADC_BITWIDTH_12,
        .atten = ADC_ATTEN_DB_12,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle, POT_ADC_CHANNEL, &adc_config));

    printf("Sistema de Monitoramento ADC/PWM Inicializado (GPIOs 4, 2 e 15).\n");

    // 4. Configuração e Inicialização do Timer Periódico (esp_timer)
    const esp_timer_create_args_t periodic_timer_args = {
        .callback = &system_timer_callback,
        .name = "adc_ledc_timer"
    };

    esp_timer_handle_t periodic_timer;
    ESP_ERROR_CHECK(esp_timer_create(&periodic_timer_args, &periodic_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(periodic_timer, SAMPLING_PERIOD_US));
}