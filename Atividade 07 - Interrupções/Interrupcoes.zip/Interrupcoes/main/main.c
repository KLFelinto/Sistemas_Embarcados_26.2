#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_attr.h"
#include "esp_rom_sys.h"

// Mapeamento de Pinos para ESP32-S3
#define BUTTON_PIN GPIO_NUM_4
#define LED_PIN    GPIO_NUM_2

// Tempos em microssegundos (us)
#define DEBOUNCE_TIME_US     25000ULL     // 25 ms (debounce)
#define LONG_PRESS_TIME_US   2000000ULL   // 2 segundos (desligamento manual)
#define LED_TIMEOUT_US       10000000ULL  // 10 segundos (desligamento automático)

// Handles dos Temporizadores do ESP32
static esp_timer_handle_t led_timer_handle = NULL;
static esp_timer_handle_t long_press_timer_handle = NULL;

// Variáveis de controle acessadas dentro da ISR
static volatile int64_t last_isr_time = 0;
static volatile int last_button_state = 0;

// Callback do Temporizador de Desligamento Automático (10s)
static void led_timer_callback(void* arg) {
    gpio_set_level(LED_PIN, 0);
    printf("Tempo esgotado (10s) -> LED DESLIGADO automaticamente.\n");
}

// Callback do Temporizador de Pressionamento Longo (2s)
static void long_press_timer_callback(void* arg) {
    // Cancela o temporizador de 10s se estiver ativo
    if (esp_timer_is_active(led_timer_handle)) {
        esp_timer_stop(led_timer_handle);
    }
    
    // Desliga o LED imediatamente
    gpio_set_level(LED_PIN, 0);
    printf("Pressionamento longo (>=2s) -> LED DESLIGADO manualmente.\n");
}

// Rotina de Interrupção de Hardware (ISR) - Alocada na IRAM
static void IRAM_ATTR gpio_isr_handler(void* arg) {
    int64_t current_time = esp_timer_get_time();

    // Filtro de Debounce por tempo
    if ((current_time - last_isr_time) < DEBOUNCE_TIME_US) {
        return;
    }

    int current_state = gpio_get_level(BUTTON_PIN);

    // Evita falsos disparos se o estado for idêntico ao já processado
    if (current_state == last_button_state) {
        return;
    }

    last_isr_time = current_time;
    last_button_state = current_state;

    if (current_state == 1) { 
        // --- Evento: Botão PRESSIONADO (Borda de Subida) ---
        gpio_set_level(LED_PIN, 1);

        // RENOVAÇÃO DO TEMPO (10s):
        if (esp_timer_is_active(led_timer_handle)) {
            esp_timer_restart(led_timer_handle, LED_TIMEOUT_US);
            esp_rom_printf("Novo clique -> Timer de 10s RENOVADO/RESETADO!\n");
        } else {
            esp_timer_start_once(led_timer_handle, LED_TIMEOUT_US);
            esp_rom_printf("Botao pressionado -> LED LIGADO / Timer (10s) iniciado.\n");
        }

        // Inicia a detecção de pressionamento longo (2s)
        if (esp_timer_is_active(long_press_timer_handle)) {
            esp_timer_restart(long_press_timer_handle, LONG_PRESS_TIME_US);
        } else {
            esp_timer_start_once(long_press_timer_handle, LONG_PRESS_TIME_US);
        }

    } else { 
        // --- Evento: Botão SOLTO (Borda de Descida) ---
        // Cancela apenas o timer de pressionamento longo
        if (esp_timer_is_active(long_press_timer_handle)) {
            esp_timer_stop(long_press_timer_handle);
        }
    }
}

void app_main(void) {
    // 1. Configuração do GPIO do LED (Saída)
    gpio_config_t led_conf = {
        .pin_bit_mask = (1ULL << LED_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&led_conf);
    gpio_set_level(LED_PIN, 0);

    // 2. Configuração do GPIO do Botão (Entrada com interrupções)
    gpio_config_t btn_conf = {
        .pin_bit_mask = (1ULL << BUTTON_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_ANYEDGE
    };
    gpio_config(&btn_conf);

    // 3. Criação dos Temporizadores do ESP32 (esp_timer)
    const esp_timer_create_args_t led_timer_args = {
        .callback = &led_timer_callback,
        .name = "led_timeout_timer"
    };
    esp_timer_create(&led_timer_args, &led_timer_handle);

    const esp_timer_create_args_t long_press_timer_args = {
        .callback = &long_press_timer_callback,
        .name = "long_press_timer"
    };
    esp_timer_create(&long_press_timer_args, &long_press_timer_handle);

    // 4. Instalação do Serviço ISR
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BUTTON_PIN, gpio_isr_handler, NULL);

    printf("Sistema iniciado (Event-Driven via ISR e Timers).\n");

    // 5. Deleta a tarefa app_main sem laços de polling ou delays bloqueantes
    vTaskDelete(NULL);
}