#include <stdio.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "driver/i2c.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_timer.h"

// ============================================================================
// MAPEAMENTO DE PINOS E CONFIGURAÇÕES
// ============================================================================
#define POT_ADC_UNIT        ADC_UNIT_2
#define POT_ADC_CHANNEL     ADC_CHANNEL_0 // GPIO 4 (ADC2_CH0)
#define BUTTON_GPIO         GPIO_NUM_2    // GPIO 2
#define LED_GPIO            GPIO_NUM_15   // GPIO 15

#define I2C_MASTER_NUM      I2C_NUM_0
#define I2C_MASTER_SDA_IO   18            // GPIO 18 (SDA)
#define I2C_MASTER_SCL_IO   19            // GPIO 19 (SCL)
#define I2C_MASTER_FREQ_HZ  100000        // 100 kHz (Standard Mode)
#define MPU6050_ADDR        0x68          // Endereço I2C do MPU6050

#define LEDC_MODE           LEDC_LOW_SPEED_MODE
#define LEDC_CHANNEL        LEDC_CHANNEL_0
#define LEDC_TIMER          LEDC_TIMER_0
#define LEDC_DUTY_RES       LEDC_TIMER_13_BIT // Resolução de 13 bits (0 a 8191)
#define LEDC_FREQUENCY      5000              // 5 kHz

#define DEBOUNCE_TIME_MS    200

// ============================================================================
// ESTRUTURAS DE DADOS E IPC
// ============================================================================
typedef struct {
    int adc_raw;
    uint32_t voltage_mv;
    uint32_t duty_13bit;
    uint8_t led_percentage;
    bool is_hold;
    float accel_x;
    float accel_y;
    float accel_z;
} system_data_t;

// Recursos Compartilhados e IPC
static system_data_t g_system_data = {0};
static SemaphoreHandle_t xSystemMutex = NULL;
static SemaphoreHandle_t xButtonSemaphore = NULL;
static QueueHandle_t xAdcQueue = NULL;
static adc_oneshot_unit_handle_t adc_handle = NULL;

// ============================================================================
// FUNÇÕES AUXILIARES I2C / MPU6050
// ============================================================================
static esp_err_t mpu6050_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_param_config(I2C_MASTER_NUM, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_MASTER_NUM, conf.mode, 0, 0, 0));

    // Acorda o MPU6050 escrevendo 0 no registrador PWR_MGMT_1 (0x6B)
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MPU6050_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x6B, true);
    i2c_master_write_byte(cmd, 0x00, true);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, pdMS_TO_TICKS(1000));
    i2c_cmd_link_delete(cmd);

    // Configura escala do acelerômetro para +/- 2g (0x1C = 0x00)
    cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MPU6050_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x1C, true);
    i2c_master_write_byte(cmd, 0x00, true);
    i2c_master_stop(cmd);
    i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, pdMS_TO_TICKS(1000));
    i2c_cmd_link_delete(cmd);

    return ret;
}

static esp_err_t mpu6050_read_accel(float *ax, float *ay, float *az)
{
    uint8_t data[6];
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MPU6050_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x3B, true); // ACCEL_XOUT_H
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (MPU6050_ADDR << 1) | I2C_MASTER_READ, true);
    i2c_master_read(cmd, data, 6, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(I2C_MASTER_NUM, cmd, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd);

    if (ret == ESP_OK) {
        int16_t raw_x = (data[0] << 8) | data[1];
        int16_t raw_y = (data[2] << 8) | data[3];
        int16_t raw_z = (data[4] << 8) | data[5];

        // Sensibilidade de 16384 LSB/g (Escala +-2g)
        *ax = (float)raw_x / 16384.0f;
        *ay = (float)raw_y / 16384.0f;
        *az = (float)raw_z / 16384.0f;
    }
    return ret;
}

// ============================================================================
// FREERTOS TASKS
// ============================================================================

// Task 1: Leitura do Botão com Debounce (Gera Semáforo Binário)
static void vTaskButton(void *pvParameters)
{
    int last_state = 0;
    int64_t last_press_time = 0;

    while (1) {
        int current_state = gpio_get_level(BUTTON_GPIO);
        int64_t now_ms = esp_timer_get_time() / 1000;

        if (current_state == 1 && last_state == 0) {
            if ((now_ms - last_press_time) > DEBOUNCE_TIME_MS) {
                xSemaphoreGive(xButtonSemaphore); // Sinaliza mudança de estado
                last_press_time = now_ms;
            }
        }
        last_state = current_state;
        vTaskDelay(pdMS_TO_TICKS(20)); // Bloqueio temporal
    }
}

// Task 2: Amostragem do ADC e envio para Fila (Queue)
static void vTaskADC(void *pvParameters)
{
    int raw_val = 0;

    while (1) {
        if (adc_oneshot_read(adc_handle, POT_ADC_CHANNEL, &raw_val) == ESP_OK) {
            // Envia o valor bruto do ADC para a fila
            xQueueSend(xAdcQueue, &raw_val, pdMS_TO_TICKS(10));
        }
        vTaskDelay(pdMS_TO_TICKS(30)); // Período de amostragem
    }
}

// Task 3: Atualização do LED PWM conforme Fila e Estado HOLD (Semáforo Binário)
static void vTaskLED(void *pvParameters)
{
    int received_adc = 0;
    bool mode_hold = false;
    uint32_t duty_13bit = 0;

    while (1) {
        // Verifica se o botão foi pressionado (Semáforo Binário não-bloqueante)
        if (xSemaphoreTake(xButtonSemaphore, 0) == pdTRUE) {
            mode_hold = !mode_hold; // Alterna estado LIVE / HOLD
        }

        // Processa dado da Fila
        if (xQueueReceive(xAdcQueue, &received_adc, pdMS_TO_TICKS(20)) == pdTRUE) {
            if (!mode_hold) {
                // Escalonamento para 13 bits (0 a 8191)
                duty_13bit = (received_adc * 8191) / 4095;
                
                ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, duty_13bit);
                ledc_update_duty(LEDC_MODE, LEDC_CHANNEL);
            }
        }

        // Atualização da Estrutura Compartilhada com Proteção por Mutex
        if (xSemaphoreTake(xSystemMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
            g_system_data.adc_raw = received_adc;
            g_system_data.voltage_mv = (received_adc * 3300) / 4095;
            g_system_data.duty_13bit = duty_13bit;
            g_system_data.led_percentage = (duty_13bit * 100) / 8191;
            g_system_data.is_hold = mode_hold;
            xSemaphoreGive(xSystemMutex);
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

// Task 4: Leitura da IMU MPU6050 via I2C
static void vTaskIMU(void *pvParameters)
{
    float ax = 0.0f, ay = 0.0f, az = 0.0f;

    while (1) {
        if (mpu6050_read_accel(&ax, &ay, &az) == ESP_OK) {
            if (xSemaphoreTake(xSystemMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
                g_system_data.accel_x = ax;
                g_system_data.accel_y = ay;
                g_system_data.accel_z = az;
                xSemaphoreGive(xSystemMutex);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

// Task 5: Telemetria Serial Formatada (Exibição a cada 500ms)
static void vTaskTelemetry(void *pvParameters)
{
    system_data_t local_data;

    while (1) {
        // Leitura atômica dos dados protegidos por Mutex
        if (xSemaphoreTake(xSystemMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            local_data = g_system_data;
            xSemaphoreGive(xSystemMutex);

            printf("=====================================================\n");
            printf("STATUS: [%s] | ", local_data.is_hold ? "HOLD" : "LIVE");
            printf("POT: %4d (%4lu mV) | LED: %3d%%\n", 
                   local_data.adc_raw, 
                   local_data.voltage_mv, 
                   local_data.led_percentage);
            printf("IMU ACCEL (g): ");
            printf("X:%6.2f | Y:%6.2f | Z:%6.2f\n", 
                   local_data.accel_x, 
                   local_data.accel_y, 
                   local_data.accel_z);
            printf("=====================================================\n\n");
        }

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// ============================================================================
// MAIN / INICIALIZAÇÃO
// ============================================================================
void app_main(void)
{
    // 1. Criação dos Mecanismos de IPC (FreeRTOS)
    xSystemMutex = xSemaphoreCreateMutex();
    xButtonSemaphore = xSemaphoreCreateBinary();
    xAdcQueue = xQueueCreate(5, sizeof(int));

    // 2. Configuração do Botão (GPIO 2)
    gpio_config_t btn_cfg = {
        .pin_bit_mask = (1ULL << BUTTON_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&btn_cfg);

    // 3. Configuração do PWM LEDC (GPIO 15 - 13 bits)
    ledc_timer_config_t ledc_timer = {
        .speed_mode = LEDC_MODE,
        .timer_num = LEDC_TIMER,
        .duty_resolution = LEDC_DUTY_RES,
        .freq_hz = LEDC_FREQUENCY,
        .clk_cfg = LEDC_AUTO_CLK
    };
    ESP_ERROR_CHECK(ledc_timer_config(&ledc_timer));

    ledc_channel_config_t ledc_channel = {
        .speed_mode = LEDC_MODE,
        .channel = LEDC_CHANNEL,
        .timer_sel = LEDC_TIMER,
        .intr_type = LEDC_INTR_DISABLE,
        .gpio_num = LED_GPIO,
        .duty = 0,
        .hpoint = 0
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ledc_channel));

    // 4. Configuração do ADC1 (GPIO 4 - Canal 0)
    adc_oneshot_unit_init_cfg_t adc_init_cfg = {
        .unit_id = POT_ADC_UNIT,
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&adc_init_cfg, &adc_handle));

    adc_oneshot_chan_cfg_t adc_chan_cfg = {
        .bitwidth = ADC_BITWIDTH_12,
        .atten = ADC_ATTEN_DB_12,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle, POT_ADC_CHANNEL, &adc_chan_cfg));

    // 5. Inicialização da IMU MPU6050 (I2C)
    mpu6050_init();

    // 6. Criação das Tarefas Multitarefa (FreeRTOS Tasks)
    xTaskCreate(vTaskButton,    "TaskButton",    2048, NULL, 4, NULL);
    xTaskCreate(vTaskLED,       "TaskLED",       2048, NULL, 3, NULL);
    xTaskCreate(vTaskADC,       "TaskADC",       2048, NULL, 2, NULL);
    xTaskCreate(vTaskIMU,       "TaskIMU",       3072, NULL, 2, NULL);
    xTaskCreate(vTaskTelemetry, "TaskTelemetry", 3072, NULL, 1, NULL);
}